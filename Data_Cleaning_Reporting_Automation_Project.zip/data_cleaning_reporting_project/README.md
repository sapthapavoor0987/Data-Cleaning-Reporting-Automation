# Data Cleaning & Reporting Automation

Python project that automatically cleans messy sales data and generates business reports.

## Features
- Handles missing values
- Removes duplicate orders
- Standardizes inconsistent text and formats
- Converts dates and numeric fields
- Calculates sales automatically
- Generates summary, monthly, and product reports
- Exports clean CSV files for further Excel analysis

## Run
```bash
pip install -r requirements.txt
python data_cleaning_automation.py
```
