import pandas as pd
import numpy as np
from pathlib import Path

INPUT = "raw_sales_data.csv"
OUTPUT = "cleaned_sales_data.csv"
SUMMARY = "automated_report.csv"

# Load data
df = pd.read_csv(INPUT)

# Track data quality before cleaning
before_rows = len(df)
duplicate_rows = df.duplicated().sum()
missing_before = int(df.isna().sum().sum())

# Standardize column names
df.columns = (
    df.columns.str.strip()
              .str.lower()
              .str.replace(" ", "_")
)

# Clean text fields
text_cols = ["customer", "region", "product", "salesperson"]
for col in text_cols:
    df[col] = df[col].astype("string").str.strip()

df["region"] = df["region"].str.title()
df["product"] = df["product"].str.title()
df["salesperson"] = df["salesperson"].str.title()

# Clean dates with mixed formats
df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=False)

# Clean numeric fields
df["quantity"] = (
    df["quantity"].astype("string").str.strip().str.replace(",", "", regex=False)
)
word_numbers = {
    "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
    "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10"
}
df["quantity"] = df["quantity"].str.lower().replace(word_numbers)
df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")

df["unit_price"] = (
    df["unit_price"].astype("string").str.replace(",", "", regex=False)
)
df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")

# Fill missing values using sensible rules
df["quantity"] = df["quantity"].fillna(df["quantity"].median())
df["unit_price"] = df["unit_price"].fillna(df["unit_price"].median())
df["region"] = df["region"].fillna("Unknown")
df["salesperson"] = df["salesperson"].fillna("Unknown")

# Remove duplicate order IDs, keeping the first record
df = df.drop_duplicates(subset=["order_id"], keep="first")

# Calculate sales and reporting fields
df["sales"] = df["quantity"] * df["unit_price"]
df["month"] = df["date"].dt.strftime("%b %Y")

# Save cleaned dataset
df.to_csv(OUTPUT, index=False)

# Automated summary report
summary = pd.DataFrame({
    "Metric": [
        "Rows before cleaning",
        "Rows after cleaning",
        "Duplicate rows detected",
        "Missing cells before cleaning",
        "Total sales",
        "Total quantity",
        "Average order value",
        "Number of customers",
        "Number of products",
        "Number of regions"
    ],
    "Value": [
        before_rows,
        len(df),
        duplicate_rows,
        missing_before,
        round(df["sales"].sum(), 2),
        round(df["quantity"].sum(), 2),
        round(df["sales"].mean(), 2),
        df["customer"].nunique(),
        df["product"].nunique(),
        df["region"].nunique()
    ]
})
summary.to_csv(SUMMARY, index=False)

# Additional reporting tables
monthly = df.groupby("month", dropna=False)["sales"].sum().reset_index()
monthly.columns = ["Month", "Sales"]
monthly.to_csv("monthly_sales_report.csv", index=False)

product = (
    df.groupby("product")["sales"]
      .sum()
      .sort_values(ascending=False)
      .reset_index()
)
product.columns = ["Product", "Sales"]
product.to_csv("product_sales_report.csv", index=False)

print("DATA CLEANING & REPORTING AUTOMATION")
print("-------------------------------------")
print(f"Rows before cleaning: {before_rows}")
print(f"Rows after cleaning:  {len(df)}")
print(f"Duplicates detected:  {duplicate_rows}")
print(f"Missing cells fixed:  {missing_before}")
print(f"Total sales:          ₹{df['sales'].sum():,.0f}")
print(f"Average order value:  ₹{df['sales'].mean():,.0f}")
print("\nTop products:")
print(product.to_string(index=False))
